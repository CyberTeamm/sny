#!/bin/bash
clear
echo "starting tools... /";
sleep 0.1;
clear
echo 'Starting tools... -';
sleep 0.1;
clear
figlet -f pagga CyberTeam|lolcat
     	       
echo """

Yapımcı : Sinyalci

Grup : CyberTeam

Github : CyberTeamm


				
 ###################################
# Sinyalci / K4ra / Unknown / Nefer #
 ###################################"""|lolcat
echo			           
echo						
echo '';            
echo 'Seçenekler'|lolcat		
echo	           
echo '[1] Sitelerin Açıklarını Bul'|lolcat
echo ''               
read -p "Sinyalci@Root > " command
if [ $command -eq 1 ];
	then
		cd data/ && chmod +x subdo.sh && ./subdo.sh
elif [ $command -eq 2 ];
	then
		cd data/ && chmod +x submit.sh && ./submit.sh
elif [ $command -eq 3 ];
	then
		cd data/ && chmod +x spoof.sh && ./spoof.sh
fi
