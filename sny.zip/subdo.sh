#!/bin/bash
clear
figlet -f pagga CyberTeam
	         	
echo '';			   
read -p "URL >  http://" domain    
read -p "Bulunacak Miktar  (1-5 ) > " delay
read -p "Kaç Açık Verilsin 1-10000 > " jumlah
read -p "Açıkları Kaydedilecek Dosyanin Adı ( test.txt ) >" output
echo "[+] Bulunuyor..."|lolcat       	
count=1
while [ $count -le $jumlah ]
do
printf "http://$RANDOM.$domain\n" >> $output
echo "[$count] Bulunanlar Buraya Kaydediliyor => data/$output"|lolcat
sleep $delay             					
(( count++ ))
done
echo "[+] Tamamlandı"|lolcat

